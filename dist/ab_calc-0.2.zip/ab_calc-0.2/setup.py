from distutils.core import setup
setup(
  name = 'ab_calc',
  packages = ['ab_calc'], 
  version = '0.2',
  description = 'ab calculation lib',
  author = 'AS',
  author_email = 'alexandersisyov@gmail.com',
  url = 'https://github.com/AlexanderSisev/ab_rep',
  download_url = 'https://github.com/AlexanderSisev/ab_rep/tarball/0.2',
  keywords = ['ab', 'ab_test'],
  classifiers = [],
)
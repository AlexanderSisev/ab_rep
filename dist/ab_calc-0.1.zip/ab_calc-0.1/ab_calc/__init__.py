from .ab_calc import *

VERSION = (0, 0, 2)
__version__ = VERSION
__versionstr__ = '.'.join(map(str, VERSION))